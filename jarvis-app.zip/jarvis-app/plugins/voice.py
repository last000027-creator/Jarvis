"""
Voice plugin
------------
Adds two things to the assistant:
  - speak(text): reads text out loud
  - VoiceListener: tap-to-talk speech recognition (Android only)

On Android this uses the built-in Android speech recognizer (the same one
behind the microphone icon in Google's keyboard), so no extra API key or
internet service is needed beyond what Android itself provides.

On desktop (for testing in a plain `python main.py` run), speak() will try
plyer's TTS and silently do nothing if unavailable, and voice input is not
supported — use the text box instead.

IMPORTANT: This has not been tested on a real device from this environment
(no Android hardware or build tools available here). Speech recognition in
particular is the most likely thing to need a tweak once you try it on your
phone — if the mic button doesn't respond, check:
  1. That you tapped "Allow" on the microphone permission prompt on first use
  2. That buildozer.spec includes RECORD_AUDIO in android.permissions (it does)
  3. Android device logs (`adb logcat`) for the actual error if it silently fails
"""

from kivy.utils import platform
from kivy.clock import mainthread

_is_android = platform == "android"

if _is_android:
    from jnius import autoclass, PythonJavaClass, java_method
    from android.permissions import request_permissions, Permission, check_permission

    PythonActivity = autoclass("org.kivy.android.PythonActivity")
    SpeechRecognizer = autoclass("android.speech.SpeechRecognizer")
    RecognizerIntent = autoclass("android.speech.RecognizerIntent")
    Intent = autoclass("android.content.Intent")
    Locale = autoclass("java.util.Locale")
    TextToSpeech = autoclass("android.speech.tts.TextToSpeech")

    _tts_engine = [None]

    def _init_tts():
        if _tts_engine[0] is None:
            activity = PythonActivity.mActivity
            _tts_engine[0] = TextToSpeech(activity, None)
        return _tts_engine[0]

    def speak(text):
        try:
            engine = _init_tts()
            engine.setLanguage(Locale.getDefault())
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, None, None)
        except Exception as e:
            print(f"[voice] TTS error: {e}")

    class _RecognitionListener(PythonJavaClass):
        __javainterfaces__ = ["android/speech/RecognitionListener"]
        __javacontext__ = "app"

        def __init__(self, on_result, on_error):
            super().__init__()
            self.on_result = on_result
            self.on_error = on_error

        @java_method("(Landroid/os/Bundle;)V")
        def onResults(self, bundle):
            matches = bundle.getStringArrayList(
                SpeechRecognizer.RESULTS_RECOGNITION
            )
            text = matches.get(0) if matches and matches.size() > 0 else ""
            self.on_result(text)

        @java_method("(I)V")
        def onError(self, error_code):
            self.on_error(f"Speech recognizer error code: {error_code}")

        # Required no-op overrides
        @java_method("(Landroid/os/Bundle;)V")
        def onReadyForSpeech(self, bundle):
            pass

        @java_method("()V")
        def onBeginningOfSpeech(self):
            pass

        @java_method("(F)V")
        def onRmsChanged(self, rmsdB):
            pass

        @java_method("([B)V")
        def onBufferReceived(self, buffer):
            pass

        @java_method("()V")
        def onEndOfSpeech(self):
            pass

        @java_method("(Landroid/os/Bundle;)V")
        def onPartialResults(self, bundle):
            pass

        @java_method("(ILandroid/os/Bundle;)V")
        def onEvent(self, event_type, bundle):
            pass

    class VoiceListener:
        """Tap-to-talk speech recognition. Call start(on_result, on_error)."""

        def __init__(self):
            self._recognizer = None

        def ensure_permission(self, callback):
            if check_permission(Permission.RECORD_AUDIO):
                callback(True)
            else:
                def cb(perms, grants):
                    callback(all(grants))
                request_permissions([Permission.RECORD_AUDIO], cb)

        def start(self, on_result, on_error):
            def _go(granted):
                if not granted:
                    on_error("Microphone permission was not granted.")
                    return
                try:
                    activity = PythonActivity.mActivity
                    self._recognizer = SpeechRecognizer.createSpeechRecognizer(activity)
                    listener = _RecognitionListener(
                        lambda text: mainthread(lambda dt: on_result(text))(),
                        lambda err: mainthread(lambda dt: on_error(err))(),
                    )
                    self._recognizer.setRecognitionListener(listener)

                    intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    intent.putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
                    )
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    self._recognizer.startListening(intent)
                except Exception as e:
                    on_error(f"Could not start listening: {e}")

            self.ensure_permission(_go)

else:
    # Desktop fallback so `python main.py` still runs for quick UI testing.
    try:
        from plyer import tts as _plyer_tts
    except Exception:
        _plyer_tts = None

    def speak(text):
        if _plyer_tts:
            try:
                _plyer_tts.speak(message=text)
            except Exception as e:
                print(f"[voice] TTS unavailable on this platform: {e}")
        else:
            print(f"[voice] (would speak): {text}")

    class VoiceListener:
        def start(self, on_result, on_error):
            on_error("Voice input is only available on Android in this build. Use the text box on desktop.")
