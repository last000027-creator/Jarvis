"""
Self-upgrade plugin
--------------------
This is the "upgrade yourself" feature: you describe a new feature in plain
language, the assistant asks Claude to write it as a plugin file, and shows
you the generated code to Accept or Reject before it's ever installed or run.

Nothing here executes generated code automatically. That review step is
intentional: generated code runs with the same permissions as the rest of
the app (internet, microphone, your stored API key), so it deserves a look
before it's trusted, the same as any code you'd paste from the internet.

Flow:
  1. generate_plugin(instruction, api_key) -> (filename, code)
     Calls Claude, gets back one Python file, saves it to plugins/pending/,
     returns the filename and code so the UI can show it to you.
  2. You review the code in the app.
  3. If you tap Accept -> plugin_loader.install_from_pending(filename)
     If you tap Reject -> plugin_loader.reject_pending(filename)
"""

import json
import os
import re
import urllib.request

from . import plugin_loader

API_URL = "https://api.anthropic.com/v1/messages"
MODEL = "claude-sonnet-4-5"

SYSTEM_PROMPT = """You write small, self-contained Python plugin files for a \
Kivy-based personal assistant app running on Android.

Rules for the plugin file you write:
- It must define exactly one function: on_command(text) -> str or None
  - Inspect `text` (the user's message, already lowercased is NOT guaranteed,
    do your own .lower() if needed) and decide whether this plugin handles it.
  - Return a string reply if it handles the message.
  - Return None if it does not, so other plugins or the main AI can handle it.
- Only use Python standard library, or `plyer` (already included) and, on
  Android specifically, `jnius`/`android.permissions` guarded by
  `from kivy.utils import platform; if platform == "android": ...` — never
  assume Android-only modules are available, always guard imports.
- No network calls to any service other than ones the user explicitly asked
  for in their instruction.
- No file deletion, no shell commands, no reading of files outside this
  app's own folder.
- Output ONLY the raw Python code for the file. No markdown fences, no
  explanation before or after.
"""


def _slugify(instruction):
    slug = re.sub(r"[^a-z0-9]+", "_", instruction.lower()).strip("_")
    return slug[:40] or "feature"


def generate_plugin(instruction, api_key):
    """Ask Claude to write a plugin implementing `instruction`.
    Returns (filename, code). Raises Exception on failure."""

    payload = {
        "model": MODEL,
        "max_tokens": 1500,
        "system": SYSTEM_PROMPT,
        "messages": [
            {
                "role": "user",
                "content": f"Write a plugin for this feature request: {instruction}",
            }
        ],
    }

    req = urllib.request.Request(
        API_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        },
        method="POST",
    )

    with urllib.request.urlopen(req, timeout=45) as resp:
        data = json.loads(resp.read().decode("utf-8"))

    code = "".join(
        block.get("text", "") for block in data.get("content", [])
        if block.get("type") == "text"
    ).strip()

    # Strip markdown fences if the model added them anyway
    code = re.sub(r"^```(python)?\n", "", code)
    code = re.sub(r"\n```$", "", code)

    if "def on_command" not in code:
        raise ValueError(
            "The generated code didn't match the expected plugin format "
            "(missing on_command function). Nothing was saved."
        )

    filename = f"{_slugify(instruction)}.py"
    path = os.path.join(plugin_loader.PENDING_DIR, filename)

    # avoid overwriting an existing pending file with the same name
    counter = 1
    base_filename = filename
    while os.path.exists(path):
        filename = f"{base_filename[:-3]}_{counter}.py"
        path = os.path.join(plugin_loader.PENDING_DIR, filename)
        counter += 1

    with open(path, "w") as f:
        f.write(code)

    return filename, code
