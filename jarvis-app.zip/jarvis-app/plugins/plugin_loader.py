"""
Plugin loader
-------------
Loads every .py file in plugins/active/ as a plugin. Each plugin file must
define a function:

    def on_command(text: str):
        # return a string reply if this plugin handles the message,
        # or return None to let other plugins / the main AI handle it
        ...

Plugins are tried in alphabetical order. The first one that returns a
non-None value "wins" and its reply is shown instead of calling the main
Claude API for that message.

This module also handles backup/rollback: before installing a new plugin,
the whole active/ folder is copied to backup/, so a bad upgrade can be
undone with rollback_last().
"""

import importlib.util
import os
import shutil
import sys

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ACTIVE_DIR = os.path.join(APP_DIR, "plugins", "active")
PENDING_DIR = os.path.join(APP_DIR, "plugins", "pending")
BACKUP_DIR = os.path.join(APP_DIR, "plugins", "backup")

for d in (ACTIVE_DIR, PENDING_DIR, BACKUP_DIR):
    os.makedirs(d, exist_ok=True)

_loaded_modules = []


def load_all():
    """(Re)load every plugin in active/. Call this at startup and after
    installing an upgrade."""
    global _loaded_modules
    _loaded_modules = []

    for fname in sorted(os.listdir(ACTIVE_DIR)):
        if not fname.endswith(".py") or fname == "__init__.py":
            continue
        path = os.path.join(ACTIVE_DIR, fname)
        modname = f"active_plugin_{fname[:-3]}"
        try:
            spec = importlib.util.spec_from_file_location(modname, path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[modname] = module
            spec.loader.exec_module(module)
            if hasattr(module, "on_command"):
                _loaded_modules.append((fname, module))
        except Exception as e:
            print(f"[plugin_loader] Failed to load {fname}: {e}")

    return [name for name, _ in _loaded_modules]


def handle_command(text):
    """Give every loaded plugin a chance to handle this message.
    Returns a reply string, or None if no plugin handled it (meaning the
    main AI API should answer instead)."""
    for fname, module in _loaded_modules:
        try:
            result = module.on_command(text)
            if result is not None:
                return result
        except Exception as e:
            print(f"[plugin_loader] Plugin {fname} raised an error: {e}")
    return None


def backup_active():
    """Snapshot the current active/ folder before making a change."""
    if os.path.exists(BACKUP_DIR):
        shutil.rmtree(BACKUP_DIR)
    shutil.copytree(ACTIVE_DIR, BACKUP_DIR)


def install_from_pending(filename):
    """Move a reviewed, accepted plugin from pending/ to active/, backing
    up the previous state first."""
    backup_active()
    src = os.path.join(PENDING_DIR, filename)
    dst = os.path.join(ACTIVE_DIR, filename)
    shutil.move(src, dst)
    return load_all()


def reject_pending(filename):
    path = os.path.join(PENDING_DIR, filename)
    if os.path.exists(path):
        os.remove(path)


def rollback_last():
    """Restore active/ from the last backup (undoes the most recent upgrade)."""
    if not os.path.exists(BACKUP_DIR) or not os.listdir(BACKUP_DIR):
        return False
    if os.path.exists(ACTIVE_DIR):
        shutil.rmtree(ACTIVE_DIR)
    shutil.copytree(BACKUP_DIR, ACTIVE_DIR)
    load_all()
    return True
